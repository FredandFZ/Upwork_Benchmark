
from __future__ import annotations

from copy import deepcopy
import hashlib
import re

from current_state import FEATURES


class DomainError(ValueError):
    pass


_FEATURES = {item["slug"]: deepcopy(item) for item in FEATURES}


def _feature(slug):
    return _FEATURES.get(slug)


def _attrs(slug):
    item = _feature(slug)
    return deepcopy(item.get("attributes") or {}) if item else {}


def _find(*terms):
    terms = tuple(term.lower() for term in terms)
    for slug, feature in _FEATURES.items():
        haystack = " ".join((slug, feature.get("title", ""))).lower()
        if all(term in haystack for term in terms):
            return deepcopy(feature.get("attributes") or {})
    return {}


def _has_term(term):
    term = term.lower()
    return any(term in " ".join((slug, feature.get("title", ""))).lower()
               for slug, feature in _FEATURES.items())


def _number(value, default=0.0):
    if isinstance(value, (int, float)):
        return float(value)
    match = re.search(r"-?\d+(?:\.\d+)?", str(value).replace(",", ""))
    return float(match.group()) if match else float(default)


def _ok(body, status=200):
    return {"status": status, "body": body}


class SilverPineService:
    def __init__(self):
        self.gallery_selection = None
        self.quotes = []

    def routes(self):
        return [
            {"method": "GET", "path": "/api/gallery"},
            {"method": "POST", "path": "/api/gallery/selection"},
            {"method": "POST", "path": "/api/quotes"},
            {"method": "GET", "path": "/api/navigation"},
        ]

    def gallery(self):
        config = _attrs("gallery-browsing-and-organization")
        tabs = list(config.get("main_gallery_tabs") or [])
        return {"tabs": tabs, "selected": self.gallery_selection or (tabs[0] if tabs else None),
                "interaction": config.get("interaction_mode")}

    def select_gallery(self, tab):
        tab = str(tab).strip().lower()
        tabs = [str(item).lower() for item in self.gallery()["tabs"]]
        if tab not in tabs:
            raise DomainError("unknown gallery tab")
        self.gallery_selection = tab
        return self.gallery()

    @staticmethod
    def _category(square_feet):
        value = int(square_feet)
        if value < 1:
            raise DomainError("square_feet must be positive")
        if value <= 1200:
            return "under_1200_sqft"
        if value <= 2400:
            return "1201_2400_sqft"
        if value <= 3600:
            return "2401_3600_sqft"
        return "3600_plus_sqft"

    def quote(self, square_feet, package="basic", extras=None):
        pricing = _attrs("package-pricing-by-square-footage")
        key = self._category(square_feet)
        matrix = pricing.get(f"{str(package).lower()}_package_prices_by_square_footage")
        if matrix is None and str(package).lower() == "basic":
            matrix = pricing.get("basic_package_prices_by_square_footage")
        if not isinstance(matrix, dict) or key not in matrix:
            raise DomainError("the requested package has no configured price")
        base = _number(matrix[key])
        extras = list(extras or [])
        quote = {"quote_id": len(self.quotes) + 1, "package": str(package).lower(),
                 "square_feet": int(square_feet), "category": key, "base_price_usd": base,
                 "extras": extras, "total_usd": base}
        self.quotes.append(quote)
        return deepcopy(quote)

    def navigation(self):
        links = _attrs("homepage-section-button-links").get("button_destinations") or {}
        return {"links": deepcopy(links), "portfolio": _attrs("homepage-portfolio-tile-link").get("link_destination")}

    def request(self, method, path, payload=None, query=None):
        payload = payload or {}
        if method == "GET" and path == "/api/gallery":
            return _ok(self.gallery())
        if method == "POST" and path == "/api/gallery/selection":
            return _ok(self.select_gallery(payload.get("tab")))
        if method == "POST" and path == "/api/quotes":
            return _ok(self.quote(**payload), 201)
        if method == "GET" and path == "/api/navigation":
            return _ok(self.navigation())
        return {"status": 404, "body": {"error": "route not found"}}


def make_service():
    return SilverPineService()
