# Generated current behavior. Edit this module to implement requested changes.
PROJECT = {'artifact_class': 'CONTENT_AND_QUOTE_WEB_APPLICATION',
 'description': 'Offline website implementing the currently active pricing, quote, gallery, '
                'imagery, and video behavior.',
 'primary_artifacts': ['dist/index.html', 'dist/catalog.json'],
 'project_id': '44035087',
 'renderer': 'web',
 'title': '44035087'}

FEATURES = []
