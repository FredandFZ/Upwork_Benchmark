# Generated current behavior. Edit this module to implement requested changes.
PROJECT = {'artifact_class': 'SAAS_WEB_APPLICATION',
 'description': 'Offline executable SaaS website with current landing, shared-site, access, '
                'provisioning, and admin-workspace behavior.',
 'primary_artifacts': ['dist/index.html', 'dist/catalog.json'],
 'project_id': '43772711',
 'renderer': 'web',
 'title': '43772711'}

FEATURES = []
