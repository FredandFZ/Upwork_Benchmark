# Generated current behavior. Edit this module to implement requested changes.
PROJECT = {'artifact_class': 'WORD_TEMPLATE',
 'description': 'Deterministic OOXML Word-template generator exposing current styles, fields, '
                'layout, localization, and interaction behavior.',
 'primary_artifacts': ['dist/template.docx', 'dist/template-preview.html'],
 'project_id': '43255761',
 'renderer': 'docx',
 'title': '43255761'}

FEATURES = []
