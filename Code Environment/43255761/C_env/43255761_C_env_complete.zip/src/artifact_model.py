"""Editable current artifact state used by the deterministic generator."""

ARTIFACT_MODEL = {'content': [],
 'content_controls': [],
 'fields': [],
 'help': [],
 'language': 'en-US',
 'schema': 'artifact-docx-v1',
 'spacing': [],
 'styles': [{'based_on': None, 'font_size_pt': 11, 'name': 'Normal', 'type': 'paragraph'},
            {'based_on': 'Normal', 'font_size_pt': 40, 'name': 'Title', 'type': 'paragraph'}]}
