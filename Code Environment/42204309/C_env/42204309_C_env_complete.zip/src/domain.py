
from __future__ import annotations

from copy import deepcopy
import hashlib
import re

from current_state import FEATURES


class DomainError(ValueError):
    pass


_FEATURES = {item["slug"]: deepcopy(item) for item in FEATURES}


def _feature(slug):
    return _FEATURES.get(slug)


def _attrs(slug):
    item = _feature(slug)
    return deepcopy(item.get("attributes") or {}) if item else {}


def _find(*terms):
    terms = tuple(term.lower() for term in terms)
    for slug, feature in _FEATURES.items():
        haystack = " ".join((slug, feature.get("title", ""))).lower()
        if all(term in haystack for term in terms):
            return deepcopy(feature.get("attributes") or {})
    return {}


def _has_term(term):
    term = term.lower()
    return any(term in " ".join((slug, feature.get("title", ""))).lower()
               for slug, feature in _FEATURES.items())


def _number(value, default=0.0):
    if isinstance(value, (int, float)):
        return float(value)
    match = re.search(r"-?\d+(?:\.\d+)?", str(value).replace(",", ""))
    return float(match.group()) if match else float(default)


def _ok(body, status=200):
    return {"status": status, "body": body}


class CurrentPrizeService:
    def __init__(self):
        self.pools = {"small": 0.0, "big": 0.0}
        self.entries = {"small": {}, "big": {}}

    def routes(self):
        return [
            {"method": "GET", "path": "/api/prizes"},
            {"method": "POST", "path": "/api/prizes/contributions"},
            {"method": "POST", "path": "/api/prizes/draws"},
        ]

    def _rule(self, block):
        slug = "small-block-prize-mechanism" if block == "small" else "big-block-prize-mechanism"
        attrs = _attrs(slug)
        amount = _number(attrs.get("prize_amount_per_winner_usd") or
                         attrs.get("prize_amount_per_winner"))
        winners = int(_number(attrs.get("winner_count"), 0))
        return {"winner_count": winners, "prize_amount_usd": amount,
                "pool_target_usd": amount * winners}

    def prize_status(self):
        return {block: {"pool_usd": self.pools[block], "rule": self._rule(block),
                        "entry_count": sum(self.entries[block].values())}
                for block in ("small", "big")}

    def contribute(self, block, amount_usd, participant=None, entries=0):
        block = str(block or "").lower()
        if block not in self.pools:
            raise DomainError("unknown prize block")
        amount = _number(amount_usd)
        if amount < 0:
            raise DomainError("contribution must be non-negative")
        self.pools[block] += amount
        if participant and int(entries) > 0:
            key = str(participant)
            self.entries[block][key] = self.entries[block].get(key, 0) + int(entries)
        return self.prize_status()[block]

    def draw(self, block):
        block = str(block or "").lower()
        if block not in self.pools:
            raise DomainError("unknown prize block")
        rule = self._rule(block)
        if self.pools[block] < rule["pool_target_usd"]:
            raise DomainError("pool target has not been reached")
        ranked = sorted(self.entries[block], key=lambda key: (-self.entries[block][key], key))
        winners = ranked[:rule["winner_count"]]
        self.pools[block] = max(0.0, self.pools[block] - rule["pool_target_usd"])
        return {"block": block, "winners": winners, "rule": rule,
                "remaining_pool_usd": self.pools[block]}

    def request(self, method, path, payload=None, query=None):
        payload = payload or {}
        if method == "GET" and path == "/api/prizes":
            return _ok(self.prize_status())
        if method == "POST" and path == "/api/prizes/contributions":
            return _ok(self.contribute(**payload), 201)
        if method == "POST" and path == "/api/prizes/draws":
            return _ok(self.draw(payload.get("block")))
        return {"status": 404, "body": {"error": "route not found"}}


def make_service():
    return CurrentPrizeService()
