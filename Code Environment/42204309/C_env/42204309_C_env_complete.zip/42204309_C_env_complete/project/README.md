# Composite Code Environment

This is a runnable, zero-domain application shell. It preserves the observed
Solidity/Foundry build chain and adds a neutral web/API process so later
repository states can be replayed consistently.

```bash
npm ci
npm run check
npm start
curl http://localhost:3000/health
```

The web/API shell is simulated because no corresponding source snapshot was
delivered. It intentionally exposes only a health endpoint and a generic
state endpoint.
