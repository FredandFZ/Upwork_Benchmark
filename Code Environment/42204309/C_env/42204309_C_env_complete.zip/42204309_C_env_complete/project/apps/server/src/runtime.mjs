export const snapshot = Object.freeze({
  environment: "ready",
  projectName: "Application Shell",
  hero: null,
  features: [],
});

export function findFeature() {
  return null;
}
