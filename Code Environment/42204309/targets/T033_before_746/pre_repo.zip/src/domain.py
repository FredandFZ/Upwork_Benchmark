
from __future__ import annotations

from copy import deepcopy
import hashlib
import re

from current_state import FEATURES


class DomainError(ValueError):
    pass


_FEATURES = {item["slug"]: deepcopy(item) for item in FEATURES}


def _feature(slug):
    return _FEATURES.get(slug)


def _attrs(slug):
    item = _feature(slug)
    return deepcopy(item.get("attributes") or {}) if item else {}


def _find(*terms):
    terms = tuple(term.lower() for term in terms)
    for slug, feature in _FEATURES.items():
        haystack = " ".join((slug, feature.get("title", ""))).lower()
        if all(term in haystack for term in terms):
            return deepcopy(feature.get("attributes") or {})
    return {}


def _has_term(term):
    term = term.lower()
    return any(term in " ".join((slug, feature.get("title", ""))).lower()
               for slug, feature in _FEATURES.items())


def _number(value, default=0.0):
    if isinstance(value, (int, float)):
        return float(value)
    match = re.search(r"-?\d+(?:\.\d+)?", str(value).replace(",", ""))
    return float(match.group()) if match else float(default)


def _ok(body, status=200):
    return {"status": status, "body": body}


class HarborQuillService:
    def __init__(self):
        self.referrals = {}
        self.accounts = {}
        self.sessions = {}
        self.mints = []

    def routes(self):
        return [
            {"method": "POST", "path": "/api/referrals"},
            {"method": "POST", "path": "/api/mints"},
            {"method": "POST", "path": "/api/auth/magic-links"},
            {"method": "POST", "path": "/api/auth/sessions"},
            {"method": "GET", "path": "/api/dashboard"},
        ]

    def register_referral(self, owner, code=None):
        if not _has_term("referral"):
            raise DomainError("referrals are not available")
        owner = str(owner).strip()
        if not owner:
            raise DomainError("owner is required")
        code = str(code or owner).strip().upper()
        if not code or code in self.referrals:
            raise DomainError("referral code is unavailable")
        self.referrals[code] = owner
        self.accounts.setdefault(owner, {"commission_usd": 0.0, "tickets": {}, "referrals": 0})
        return {"owner": owner, "code": code}

    def request_magic_link(self, email):
        if not _feature("email-magic-link-authentication"):
            raise DomainError("email sign-in is not available")
        email = str(email).strip().lower()
        if "@" not in email:
            raise DomainError("a valid email is required")
        token = hashlib.sha256(("magic-link:" + email).encode("utf-8")).hexdigest()[:24]
        self.sessions[token] = email
        self.accounts.setdefault(email, {"commission_usd": 0.0, "tickets": {}, "referrals": 0})
        return {"email": email, "token": token, "delivery": "local-preview"}

    def sign_in(self, token):
        email = self.sessions.get(str(token))
        if not email:
            raise DomainError("invalid magic-link token")
        return {"authenticated": True, "account": email}

    def mint(self, buyer, amount_usd, asset="USDC", referral_code=None, promotional=False):
        if not _has_term("mint"):
            raise DomainError("minting is not available")
        buyer = str(buyer).strip()
        if not buyer:
            raise DomainError("buyer is required")
        asset = str(asset).upper()
        if asset == "ETH" and not _feature("eth-wallet-mint-flow"):
            raise DomainError("ETH payment is not available")
        if asset not in {"USDC", "ETH"}:
            raise DomainError("unsupported payment asset")
        pricing = _attrs("eth-pricing-and-excess-refund")
        price = _number(pricing.get("target_mint_price"), 30)
        supplied = _number(amount_usd)
        if supplied < price:
            raise DomainError("insufficient payment")
        accepted_code = str(referral_code or "").strip().upper()
        owner = self.referrals.get(accepted_code)
        rewards = {"commission_usd": 0.0, "tickets": 0, "draw_amount_usd": None}
        if owner and not promotional:
            commission = _attrs("coded-referral-commission")
            tickets = _attrs("coded-referral-ticket-issuance")
            rewards = {
                "commission_usd": _number(commission.get("commission_amount_usd")),
                "tickets": int(_number(tickets.get("tickets_per_coded_referral_mint"))),
                "draw_amount_usd": _number(tickets.get("reward_drawing_amount_usd")) or None,
            }
            account = self.accounts[owner]
            account["commission_usd"] += rewards["commission_usd"]
            draw = str(int(rewards["draw_amount_usd"] or 0))
            account["tickets"][draw] = account["tickets"].get(draw, 0) + rewards["tickets"]
            account["referrals"] += 1
        receipt = {
            "mint_id": len(self.mints) + 1,
            "buyer": buyer,
            "asset": asset,
            "charged_usd": price,
            "refund_usd_equivalent": round(supplied - price, 2),
            "referral": {"accepted": bool(owner), "owner": owner, **rewards},
            "promotional": bool(promotional),
        }
        self.mints.append(receipt)
        return deepcopy(receipt)

    def dashboard(self, owner):
        owner = str(owner).strip()
        account = self.accounts.get(owner, {"commission_usd": 0.0, "tickets": {}, "referrals": 0})
        return {"owner": owner, **deepcopy(account), "mint_count": len(self.mints)}

    def request(self, method, path, payload=None, query=None):
        payload, query = payload or {}, query or {}
        if method == "GET" and path == "/api/dashboard":
            return _ok(self.dashboard(query.get("owner", "")))
        if method == "POST" and path == "/api/referrals":
            return _ok(self.register_referral(payload.get("owner"), payload.get("code")), 201)
        if method == "POST" and path == "/api/mints":
            return _ok(self.mint(**payload), 201)
        if method == "POST" and path == "/api/auth/magic-links":
            return _ok(self.request_magic_link(payload.get("email")), 201)
        if method == "POST" and path == "/api/auth/sessions":
            return _ok(self.sign_in(payload.get("token")))
        return {"status": 404, "body": {"error": "route not found"}}


def make_service():
    return HarborQuillService()
