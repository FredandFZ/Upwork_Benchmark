"""Editable current artifact state used by the deterministic generator."""

ARTIFACT_MODEL = {'content_controls': [],
 'fields': [],
 'help': [],
 'language': 'en-US',
 'layout': {'margins_pt': [54, 54, 54, 54], 'page_size_pt': [612, 792], 'section_boxes': []},
 'package_manifest': {'assets': [],
                      'deliverables': ['security-report.docx',
                                       'security-report.pdf',
                                       'report-preview.html',
                                       'report-package.json'],
                      'variants': []},
 'pdf_coordinates': [],
 'schema': 'artifact-report-v1',
 'sections': [],
 'spacing': [],
 'styles': [{'based_on': None, 'font_size_pt': 11, 'name': 'Normal', 'type': 'paragraph'},
            {'based_on': 'Normal', 'font_size_pt': 40, 'name': 'Title', 'type': 'paragraph'}]}
