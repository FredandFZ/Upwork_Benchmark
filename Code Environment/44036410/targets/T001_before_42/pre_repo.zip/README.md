# 44036410

Deterministic security-report generator implementing current report content, variants, templates, visual structure, and exports.

## Commands

- `python scripts/build.py`
- `python scripts/check.py`
- `python -m unittest discover -s tests`
- `python src/cli.py list`
- `python scripts/serve.py`

## Structured artifact contract

Edit `src/artifact_model.py`, build the repository, then inspect the generated structure with `python scripts/inspect_artifacts.py`.
