"""Editable current artifact state used by the deterministic generator."""

ARTIFACT_MODEL = {'components': [],
 'footprints': [],
 'geometry': {'board_size': {'height': 80.0, 'width': 100.0},
              'markings': [],
              'outline': [[0.0, 0.0], [100.0, 0.0], [100.0, 80.0], [0.0, 80.0], [0.0, 0.0]],
              'units': 'mm'},
 'nets': [],
 'schema': 'artifact-kicad-v1'}
