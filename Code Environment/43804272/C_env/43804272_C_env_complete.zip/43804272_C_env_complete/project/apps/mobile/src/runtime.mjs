const features = Object.freeze([]);

export const snapshot = Object.freeze({
  environment: "completed-zero-domain-baseline",
  product: "Cross-platform mobile workspace",
  features,
});

export function featuresForPlatform(platform) {
  const component = platform === "android" ? "ANDROID_APP" : platform === "ios" ? "IOS_APP" : null;
  if (!component) return [];
  return features.filter((feature) => feature.components.includes(component) || feature.components.includes("UI_UX") || feature.components.includes("BUILD_PIPELINE"));
}

export function diagnostics() {
  return features
    .filter((feature) => feature.execution)
    .map((feature) => ({ key: feature.key, ...feature.execution }));
}

export function openQuestions() {
  return features.flatMap((feature) => feature.ambiguities.map((ambiguity) => ({ key: feature.key, ...ambiguity })));
}
