PLATFORM_BUILD = {'schema_version': 'mobile-platform-build-v1', 'platforms': ['android', 'ios'], 'current_capabilities': {}}
