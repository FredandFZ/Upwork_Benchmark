# Generated current behavior. Edit this module to implement requested changes.
PROJECT = {'artifact_class': 'CROSS_PLATFORM_MOBILE_APPLICATION',
 'description': 'Offline cross-platform mobile application model covering Android/iOS '
                'modernization, localization, measurement, and store behavior.',
 'primary_artifacts': ['dist/mobile-preview.html', 'dist/app-config.json'],
 'project_id': '43804272',
 'renderer': 'mobile',
 'title': '43804272'}

FEATURES = []
